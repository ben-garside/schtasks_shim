import schtasks_shim.query as query
import schtasks_shim.control as control